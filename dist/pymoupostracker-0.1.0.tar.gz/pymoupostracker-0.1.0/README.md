# MouseTracker Libary
A Python libary that tracks the x and y positisons of your mouse curosor